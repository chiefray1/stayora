import { useEffect } from "react";
import { BrowserRouter, Navigate, Outlet, Route, Routes, useLocation } from "react-router-dom";
import { AuthProvider, useAuth } from "./lib/auth";
import { StoreProvider } from "./lib/store";
import AppShell from "./components/AppShell";
import Landing from "./pages/Landing";
import Auth from "./pages/Auth";
import Book from "./pages/Book";
import Dashboard from "./pages/Dashboard";
import Reservations from "./pages/Reservations";
import BookingDesk from "./pages/BookingDesk";
import Rooms from "./pages/Rooms";
import Guests from "./pages/Guests";
import Housekeeping from "./pages/Housekeeping";
import Crm from "./pages/Crm";
import Reports from "./pages/Reports";
import Channels from "./pages/Channels";
import Payments from "./pages/Payments";
import Accounting from "./pages/Accounting";
import Pos from "./pages/Pos";
import Inventory from "./pages/Inventory";
import Procurement from "./pages/Procurement";
import Hr from "./pages/Hr";
import Payroll from "./pages/Payroll";
import Transport from "./pages/Transport";
import Whatsapp from "./pages/Whatsapp";
import Roles from "./pages/Roles";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import Policies from "./pages/Policies";
import Maintenance from "./pages/Maintenance";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

function Protected() {
  const { user } = useAuth();
  const location = useLocation();
  if (!user) return <Navigate to="/auth" replace state={{ from: location.pathname }} />;
  return <Outlet />;
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <StoreProvider>
          <ScrollToTop />
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/book" element={<Book />} />
            <Route path="/privacy" element={<Policies />} />
            <Route path="/refund" element={<Policies />} />

            <Route element={<Protected />}>
              <Route element={<AppShell />}>
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/reservations" element={<Reservations />} />
                <Route path="/booking-desk" element={<BookingDesk />} />
                <Route path="/rooms" element={<Rooms />} />
                <Route path="/guests" element={<Guests />} />
                <Route path="/housekeeping" element={<Housekeeping />} />
                <Route path="/maintenance" element={<Maintenance />} />
                <Route path="/crm" element={<Crm />} />
                <Route path="/reports" element={<Reports />} />
                <Route path="/channels" element={<Channels />} />
                <Route path="/payments" element={<Payments />} />
                <Route path="/accounting" element={<Accounting />} />
                <Route path="/pos" element={<Pos />} />
                <Route path="/inventory" element={<Inventory />} />
                <Route path="/procurement" element={<Procurement />} />
                <Route path="/hr" element={<Hr />} />
                <Route path="/payroll" element={<Payroll />} />
                <Route path="/transport" element={<Transport />} />
                <Route path="/whatsapp" element={<Whatsapp />} />
                <Route path="/roles" element={<Roles />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/settings" element={<Settings />} />
              </Route>
            </Route>

            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </StoreProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
