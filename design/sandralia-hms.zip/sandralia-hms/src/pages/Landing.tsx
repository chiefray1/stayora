import { useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  BarChart3,
  BedDouble,
  CalendarCheck,
  CheckCircle2,
  ConciergeBell,
  MessageCircle,
  ShieldCheck,
  Sparkles,
  Users,
} from "lucide-react";
import { buttonClass } from "../components/ui";
import CustomerAgent from "../components/CustomerAgent";

const features = [
  { icon: CalendarCheck, title: "Reservations", text: "Direct, OTA, corporate and walk-in bookings with live folios." },
  { icon: BedDouble, title: "Room rack", text: "48 keys across 4 floors with real-time status and rate plans." },
  { icon: Users, title: "Guest CRM", text: "Profiles, VIP tiers, loyalty points and lifetime value." },
  { icon: Sparkles, title: "Housekeeping", text: "Assign, track and inspect every clean from one board." },
  { icon: BarChart3, title: "Analytics", text: "Occupancy, ADR, RevPAR and departmental P&L at a glance." },
  { icon: ShieldCheck, title: "Role-based access", text: "Admin, manager, front desk, housekeeping and accounting." },
];

export default function Landing() {
  const [agentOpen, setAgentOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <div className="relative isolate overflow-hidden">
        <img
          src="/assets/hotel-night.jpg"
          alt="Sandralia Hotel illuminated in gold and blue light at night"
          className="absolute inset-0 -z-20 size-full object-cover"
        />
        <div className="absolute inset-0 -z-10 bg-[linear-gradient(180deg,rgba(0,0,0,0.28),rgba(0,0,0,0.55))]" />

        <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
          <Link to="/" className="flex items-center gap-3">
            <img src="/assets/logo.svg" alt="Sandralia Hotel" className="size-10" />
            <span className="font-display text-xl text-white drop-shadow">Sandralia</span>
          </Link>
          <div className="flex items-center gap-2">
            <Link to="/book" className={buttonClass("white", "md", "hidden sm:inline-flex")}>
              Book a room
            </Link>
            <Link to="/auth" className={buttonClass("primary", "md")}>
              Staff sign in
            </Link>
          </div>
        </header>

        <section className="mx-auto max-w-6xl px-6 pb-20 pt-10 text-center sm:pb-28 sm:pt-16">
          <p className="text-xs uppercase tracking-[0.3em] text-white/85 drop-shadow">
            Sandralia Hotel · Raising comfort to the highest level
          </p>
          <h1 className="mx-auto mt-4 max-w-3xl font-display text-4xl leading-tight text-white drop-shadow-[0_2px_12px_rgba(0,0,0,0.55)] sm:text-6xl">
            The complete operations suite for a five-star stay
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-white/95 drop-shadow-[0_1px_8px_rgba(0,0,0,0.6)]">
            Reservations, rooms, guests, housekeeping and revenue intelligence — plus a direct booking
            experience and an AI agent that books guests straight from WhatsApp.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/book" className={buttonClass("primary", "lg")}>
              <CalendarCheck className="size-4" /> Book your stay
            </Link>
            <Link to="/auth" className={buttonClass("white", "lg")}>
              Enter the suite <ArrowRight className="size-4" />
            </Link>
          </div>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-white/85">
            <span className="flex items-center gap-1.5"><CheckCircle2 className="size-3.5 text-primary" /> Best rate guarantee</span>
            <span className="flex items-center gap-1.5"><CheckCircle2 className="size-3.5 text-primary" /> Free cancellation up to 48h</span>
            <span className="flex items-center gap-1.5"><CheckCircle2 className="size-3.5 text-primary" /> Instant confirmation</span>
          </div>
        </section>
      </div>

      <main className="mx-auto max-w-6xl px-6 pb-24">
        <section className="grid gap-4 py-14 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <article key={feature.title} className="surface-card p-6">
              <span className="grid size-10 place-items-center rounded-xl bg-primary/12 text-gold">
                <feature.icon className="size-5" />
              </span>
              <h2 className="mt-4 text-lg font-semibold">{feature.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{feature.text}</p>
            </article>
          ))}
        </section>

        <section className="grid items-center gap-10 lg:grid-cols-2">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">Direct booking</p>
            <h2 className="mt-3 font-display text-3xl sm:text-4xl">
              Book in a minute — no phone call, no waiting
            </h2>
            <p className="mt-4 text-muted-foreground">
              Choose your dates, compare all four room types, add breakfast or an airport pickup, and
              receive an instant booking reference. Your reservation appears on the front desk board
              the moment you confirm.
            </p>
            <ul className="mt-5 space-y-2 text-sm text-muted-foreground">
              <li>· Live availability across all room types</li>
              <li>· Transparent Naira pricing with no hidden fees</li>
              <li>· Instant booking reference and folio</li>
              <li>· Pay online or at the hotel — your choice</li>
            </ul>
            <div className="mt-7 flex flex-wrap gap-3">
              <Link to="/book" className={buttonClass("primary", "lg")}>
                Check availability <ArrowRight className="size-4" />
              </Link>
              <button
                onClick={() => setAgentOpen(true)}
                className={buttonClass("outline", "lg")}
              >
                <MessageCircle className="size-4" /> Chat with Ada
              </button>
            </div>
          </div>

          <div className="noir-panel p-6 sm:p-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="grid size-10 place-items-center rounded-full bg-primary/15 text-primary">
                  <ConciergeBell className="size-5" />
                </span>
                <div>
                  <p className="text-sm font-semibold text-white">Ada · Sandralia booking agent</p>
                  <p className="flex items-center gap-1.5 text-[11px] text-noir-muted">
                    <span className="size-1.5 rounded-full bg-emerald-400" /> online · WhatsApp 0805 535 0960
                  </p>
                </div>
              </div>
            </div>
            <div className="mt-6 space-y-3 text-sm">
              <div className="max-w-[85%] rounded-2xl rounded-tl-sm bg-white/10 px-4 py-3 text-noir-text">
                Hello 👋 This is Ada from Sandralia Hotel. I can check room availability and book your
                stay right here. When would you like to arrive?
              </div>
              <div className="ml-auto max-w-[80%] rounded-2xl rounded-tr-sm bg-primary px-4 py-3 text-primary-foreground">
                Friday for two nights — a suite if you have one.
              </div>
              <div className="max-w-[85%] rounded-2xl rounded-tl-sm bg-white/10 px-4 py-3 text-noir-text">
                We have a Suite available at ₦200,000 per night. That's ₦400,000 for two nights. Shall I
                hold it for you?
              </div>
            </div>
            <button
              onClick={() => setAgentOpen(true)}
              className={buttonClass("white", "sm", "mt-4 w-full")}
            >
              <MessageCircle className="size-3.5" /> Continue in chat
            </button>
            <div className="mt-3 flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs text-noir-muted">
              <MessageCircle className="size-3.5" /> Ada replies instantly, 24/7
            </div>
          </div>
        </section>

        <section className="mt-20 overflow-hidden rounded-2xl border border-border bg-card">
          <div className="grid gap-6 p-8 sm:p-10 lg:grid-cols-[1.4fr_1fr] lg:items-center">
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">For the team</p>
              <h2 className="mt-2 font-display text-3xl">One suite for every corner of the hotel.</h2>
              <p className="mt-3 text-sm text-muted-foreground">
                Front desk, housekeeping, finance, F&B and management work from a single source of
                truth — with role-based access for every department.
              </p>
            </div>
            <div className="flex flex-wrap gap-3 lg:justify-end">
              <Link to="/auth" className={buttonClass("dark", "lg")}>
                Staff sign in <ArrowRight className="size-4" />
              </Link>
              <Link to="/book" className={buttonClass("outline", "lg")}>
                Guest booking
              </Link>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border bg-card">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 py-8 text-sm text-muted-foreground sm:flex-row">
          <div className="flex items-center gap-3">
            <img src="/assets/logo.svg" alt="Sandralia" className="size-8" />
            <span>© {new Date().getFullYear()} Sandralia Hotel · Lagos, Nigeria</span>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-5">
            <a href="tel:+2348055350960" className="hover:text-foreground">0805 535 0960</a>
            <Link to="/book" className="hover:text-foreground">Book a room</Link>
            <Link to="/privacy" className="hover:text-foreground">Privacy</Link>
            <Link to="/refund" className="hover:text-foreground">Refund policy</Link>
            <Link to="/auth" className="hover:text-foreground">Staff</Link>
          </div>
        </div>
      </footer>

      <CustomerAgent open={agentOpen} onOpenChange={setAgentOpen} />
    </div>
  );
}
