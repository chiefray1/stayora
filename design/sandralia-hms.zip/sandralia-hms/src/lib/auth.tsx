import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

export interface SessionUser {
  name: string;
  email: string;
  role: string;
  phone?: string;
  department?: string;
  shift?: string;
  staffId?: string;
  issuedAt?: number;
  expiresAt?: number;
}

interface AuthAccount {
  email: string;
  name: string;
  role: string;
  passwordHash?: string;
  salt?: string;
  iterations?: number;
  password?: string;
}

interface PasswordReset {
  codeHash: string;
  expiresAt: number;
  requestedAt: number;
  attempts: number;
}

interface LoginAttempt {
  count: number;
  lockedUntil: number;
}

interface AuthResult {
  ok: boolean;
  error?: string;
  code?: string;
}

type ProfilePatch = Partial<Pick<SessionUser, "name" | "email" | "phone" | "department" | "shift" | "staffId">>;

interface AuthValue {
  user: SessionUser | null;
  signIn: (email: string, password: string) => Promise<AuthResult>;
  signOut: () => void;
  changePassword: (currentPassword: string, newPassword: string) => Promise<AuthResult>;
  requestPasswordReset: (email: string) => Promise<AuthResult>;
  resetPassword: (email: string, code: string, newPassword: string) => Promise<AuthResult>;
  updateProfile: (patch: ProfilePatch) => AuthResult;
}

const AuthContext = createContext<AuthValue | null>(null);
const SESSION_KEY = "sandralia.session";
const ACCOUNTS_KEY = "sandralia.accounts.v1";
const RESETS_KEY = "sandralia.password-resets.v1";
const ATTEMPTS_KEY = "sandralia.login-attempts.v1";

const SESSION_TTL = 12 * 60 * 60 * 1000;
const RESET_TTL = 15 * 60 * 1000;
const RESET_COOLDOWN = 60 * 1000;
const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 5 * 60 * 1000;
const PBKDF2_ITERATIONS = 120_000;

const DEMO_ACCOUNTS: AuthAccount[] = [
  {
    email: "admin@sandralia.ng",
    name: "Ada Admin",
    role: "Superadmin",
    salt: "sandralia|admin@sandralia.ng|v1",
    passwordHash: "HBbFSnyCEzY8jqz0qDBoxjxfT/WQzvPuOHgv3CE5fPo=",
    iterations: PBKDF2_ITERATIONS,
  },
  {
    email: "manager@sandralia.ng",
    name: "Ngozi Manager",
    role: "Manager",
    salt: "sandralia|manager@sandralia.ng|v1",
    passwordHash: "IrC9fjFNv4Alj4la/0re2KDM0jnWNKLmSyh2KaBuTpU=",
    iterations: PBKDF2_ITERATIONS,
  },
  {
    email: "ada.obi@sandralia.ng",
    name: "Ada Obi",
    role: "Front desk",
    salt: "sandralia|ada.obi@sandralia.ng|v1",
    passwordHash: "alsz2obgtvA5e09F1jgWGno7YbXzbjc20RSEgYZM15o=",
    iterations: PBKDF2_ITERATIONS,
  },
];

const normalizeEmail = (email: string) => email.trim().toLowerCase();

const isEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

const bytesToBase64 = (bytes: Uint8Array) =>
  btoa(String.fromCharCode(...bytes));

const randomSalt = () => {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return bytesToBase64(bytes);
};

const safeEqual = (left: string, right: string) => {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index += 1) {
    difference |= left.charCodeAt(index) ^ right.charCodeAt(index);
  }
  return difference === 0;
};

const hashPassword = async (password: string, salt: string, iterations = PBKDF2_ITERATIONS) => {
  if (!globalThis.crypto?.subtle) throw new Error("Secure password hashing is unavailable.");
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(password),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      salt: new TextEncoder().encode(salt),
      iterations,
      hash: "SHA-256",
    },
    key,
    256,
  );
  return bytesToBase64(new Uint8Array(bits));
};

const hashResetCode = async (email: string, code: string) => {
  if (!globalThis.crypto?.subtle) throw new Error("Secure reset codes are unavailable.");
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(`${email}|${code}|reset-v1`),
  );
  return bytesToBase64(new Uint8Array(digest));
};

const readAccounts = (): Record<string, AuthAccount> => {
  try {
    const raw = localStorage.getItem(ACCOUNTS_KEY);
    return raw ? (JSON.parse(raw) as Record<string, AuthAccount>) : {};
  } catch {
    return {};
  }
};

const writeAccounts = (accounts: Record<string, AuthAccount>) => {
  localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
};

const readResets = (): Record<string, PasswordReset> => {
  try {
    const raw = localStorage.getItem(RESETS_KEY);
    return raw ? (JSON.parse(raw) as Record<string, PasswordReset>) : {};
  } catch {
    return {};
  }
};

const writeResets = (resets: Record<string, PasswordReset>) => {
  localStorage.setItem(RESETS_KEY, JSON.stringify(resets));
};

const readAttempts = (): Record<string, LoginAttempt> => {
  try {
    const raw = localStorage.getItem(ATTEMPTS_KEY);
    return raw ? (JSON.parse(raw) as Record<string, LoginAttempt>) : {};
  } catch {
    return {};
  }
};

const writeAttempts = (attempts: Record<string, LoginAttempt>) => {
  localStorage.setItem(ATTEMPTS_KEY, JSON.stringify(attempts));
};

const clearLoginAttempts = (email: string) => {
  const attempts = readAttempts();
  delete attempts[email];
  writeAttempts(attempts);
};

const recordFailedLogin = (email: string) => {
  const attempts = readAttempts();
  const current = attempts[email] ?? { count: 0, lockedUntil: 0 };
  const count = current.count + 1;
  attempts[email] = {
    count,
    lockedUntil: count >= MAX_ATTEMPTS ? Date.now() + LOCKOUT_MS : 0,
  };
  writeAttempts(attempts);
};

const toSession = (account: AuthAccount, previous?: SessionUser | null): SessionUser => ({
  name: account.name,
  email: account.email,
  role: account.role,
  phone: previous?.phone,
  department: previous?.department,
  shift: previous?.shift,
  staffId: previous?.staffId,
  issuedAt: previous?.issuedAt ?? Date.now(),
  expiresAt: previous?.expiresAt ?? Date.now() + SESSION_TTL,
});

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SessionUser | null>(() => {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as SessionUser;
      if (!parsed?.email || !parsed?.role) return null;
      const expiresAt = parsed.expiresAt ?? Date.now() + SESSION_TTL;
      if (expiresAt < Date.now()) {
        localStorage.removeItem(SESSION_KEY);
        return null;
      }
      const account = readAccounts()[normalizeEmail(parsed.email)];
      if (!account) {
        localStorage.removeItem(SESSION_KEY);
        return null;
      }
      return { ...toSession(account, parsed), expiresAt };
    } catch {
      return null;
    }
  });

  useEffect(() => {
    let cancelled = false;
    const prepareAccounts = async () => {
      const accounts = readAccounts();
      if (Object.keys(accounts).length === 0) {
        writeAccounts(
          Object.fromEntries(DEMO_ACCOUNTS.map((account) => [account.email, account])),
        );
        return;
      }

      let changed = false;
      for (const [email, account] of Object.entries(accounts)) {
        if (!account.password) continue;
        try {
          const salt = account.salt ?? randomSalt();
          const passwordHash = await hashPassword(account.password, salt);
          accounts[email] = {
            ...account,
            password: undefined,
            salt,
            passwordHash,
            iterations: PBKDF2_ITERATIONS,
          };
          changed = true;
        } catch {
          return;
        }
      }
      if (changed && !cancelled) writeAccounts(accounts);
    };
    void prepareAccounts();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (user) localStorage.setItem(SESSION_KEY, JSON.stringify(user));
    else localStorage.removeItem(SESSION_KEY);
  }, [user]);

  useEffect(() => {
    if (!user?.expiresAt) return;
    const remaining = user.expiresAt - Date.now();
    if (remaining <= 0) {
      setUser(null);
      return;
    }
    const timer = window.setTimeout(() => setUser(null), remaining);
    return () => window.clearTimeout(timer);
  }, [user?.expiresAt]);

  const value = useMemo<AuthValue>(
    () => ({
      user,
      signIn: async (email: string, password: string) => {
        const normalized = normalizeEmail(email);
        if (!isEmail(normalized)) return { ok: false, error: "Enter a valid work email address." };
        if (password.length < 8) return { ok: false, error: "Password must be at least 8 characters." };

        const attempts = readAttempts();
        const currentAttempt = attempts[normalized];
        if (currentAttempt?.lockedUntil && currentAttempt.lockedUntil > Date.now()) {
          const minutes = Math.max(1, Math.ceil((currentAttempt.lockedUntil - Date.now()) / 60_000));
          return { ok: false, error: `Too many failed attempts. Try again in ${minutes} minute${minutes === 1 ? "" : "s"}.` };
        }

        const accounts = readAccounts();
        const account = accounts[normalized];
        if (!account) {
          recordFailedLogin(normalized);
          return { ok: false, error: "No staff account found for that email. Contact an administrator." };
        }

        try {
          let valid = false;
          if (account.passwordHash && account.salt) {
            const candidate = await hashPassword(password, account.salt, account.iterations ?? PBKDF2_ITERATIONS);
            valid = safeEqual(candidate, account.passwordHash);
          } else if (account.password) {
            valid = safeEqual(account.password, password);
            if (valid) {
              const salt = randomSalt();
              const passwordHash = await hashPassword(password, salt);
              accounts[normalized] = {
                ...account,
                password: undefined,
                salt,
                passwordHash,
                iterations: PBKDF2_ITERATIONS,
              };
              writeAccounts(accounts);
            }
          }

          if (!valid) {
            recordFailedLogin(normalized);
            return { ok: false, error: "Incorrect password. Try again or reset it below." };
          }

          clearLoginAttempts(normalized);
          setUser(toSession(account));
          return { ok: true };
        } catch {
          return { ok: false, error: "Secure sign-in is unavailable. Open the site over HTTPS and try again." };
        }
      },
      signOut: () => setUser(null),
      changePassword: async (currentPassword: string, newPassword: string) => {
        if (!user) return { ok: false, error: "You need to be signed in to change your password." };
        if (newPassword.length < 8) return { ok: false, error: "New password must be at least 8 characters." };
        if (currentPassword === newPassword) return { ok: false, error: "Choose a password different from your current one." };

        const normalized = normalizeEmail(user.email);
        const accounts = readAccounts();
        const existing = accounts[normalized];
        if (!existing) return { ok: false, error: "Your staff account could not be found." };

        try {
          let valid = false;
          if (existing.passwordHash && existing.salt) {
            const candidate = await hashPassword(
              currentPassword,
              existing.salt,
              existing.iterations ?? PBKDF2_ITERATIONS,
            );
            valid = safeEqual(candidate, existing.passwordHash);
          } else if (existing.password) {
            valid = safeEqual(existing.password, currentPassword);
          }
          if (!valid) return { ok: false, error: "Your current password is incorrect." };

          const salt = randomSalt();
          const passwordHash = await hashPassword(newPassword, salt);
          accounts[normalized] = {
            ...existing,
            password: undefined,
            salt,
            passwordHash,
            iterations: PBKDF2_ITERATIONS,
          };
          writeAccounts(accounts);
          clearLoginAttempts(normalized);
          return { ok: true };
        } catch {
          return { ok: false, error: "Secure password hashing is unavailable. Open the site over HTTPS and try again." };
        }
      },
      requestPasswordReset: async (email: string) => {
        const normalized = normalizeEmail(email);
        if (!isEmail(normalized)) return { ok: false, error: "Enter a valid work email address." };

        const resets = readResets();
        const existing = resets[normalized];
        if (existing && Date.now() - existing.requestedAt < RESET_COOLDOWN) {
          return { ok: false, error: "Please wait a minute before requesting another code." };
        }

        try {
          const code = String(crypto.getRandomValues(new Uint32Array(1))[0] % 1_000_000).padStart(6, "0");
          resets[normalized] = {
            codeHash: await hashResetCode(normalized, code),
            expiresAt: Date.now() + RESET_TTL,
            requestedAt: Date.now(),
            attempts: 0,
          };
          writeResets(resets);
          return { ok: true, code };
        } catch {
          return { ok: false, error: "Secure reset codes are unavailable. Open the site over HTTPS and try again." };
        }
      },
      resetPassword: async (email: string, code: string, newPassword: string) => {
        const normalized = normalizeEmail(email);
        if (!isEmail(normalized)) return { ok: false, error: "Enter a valid work email address." };
        if (newPassword.length < 8) return { ok: false, error: "New password must be at least 8 characters." };

        const resets = readResets();
        const reset = resets[normalized];
        const genericError = "The reset code is incorrect or has expired. Request a new code.";
        if (!reset) return { ok: false, error: genericError };
        if (reset.expiresAt < Date.now() || reset.attempts >= MAX_ATTEMPTS) {
          delete resets[normalized];
          writeResets(resets);
          return { ok: false, error: genericError };
        }

        try {
          const candidate = await hashResetCode(normalized, code.trim());
          if (!safeEqual(candidate, reset.codeHash)) {
            reset.attempts += 1;
            if (reset.attempts >= MAX_ATTEMPTS) delete resets[normalized];
            else resets[normalized] = reset;
            writeResets(resets);
            return { ok: false, error: genericError };
          }

          const accounts = readAccounts();
          const existing = accounts[normalized];
          if (!existing) {
            delete resets[normalized];
            writeResets(resets);
            return { ok: false, error: genericError };
          }

          const salt = randomSalt();
          const passwordHash = await hashPassword(newPassword, salt);
          accounts[normalized] = {
            ...existing,
            password: undefined,
            salt,
            passwordHash,
            iterations: PBKDF2_ITERATIONS,
          };
          writeAccounts(accounts);
          delete resets[normalized];
          writeResets(resets);
          clearLoginAttempts(normalized);
          return { ok: true };
        } catch {
          return { ok: false, error: "Secure password hashing is unavailable. Open the site over HTTPS and try again." };
        }
      },
      updateProfile: (patch: ProfilePatch) => {
        if (!user) return { ok: false, error: "You need to be signed in to update your profile." };
        const previousEmail = normalizeEmail(user.email);
        const nextEmail = normalizeEmail(patch.email ?? user.email);
        if (!isEmail(nextEmail)) return { ok: false, error: "Enter a valid work email address." };

        const accounts = readAccounts();
        const account = accounts[previousEmail];
        if (!account) return { ok: false, error: "Your staff account could not be found." };
        if (nextEmail !== previousEmail && accounts[nextEmail]) {
          return { ok: false, error: "That email is already linked to another staff account." };
        }

        delete accounts[previousEmail];
        accounts[nextEmail] = {
          ...account,
          email: nextEmail,
          name: patch.name ?? account.name,
        };
        writeAccounts(accounts);

        setUser((prev) => (prev ? { ...prev, ...patch, email: nextEmail } : prev));
        return { ok: true };
      },
    }),
    [user],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
